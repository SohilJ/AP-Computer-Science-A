import java.util.Scanner;


public class PainterDriverClass
{
   public static void main(String[] args)
   {
      //Call PainterResourceClass to DriverClass
      PainterResourceClass1 PRC = new PainterResourceClass1();
      
      //Call the  methods to find area of everything.
      PRC.AreaOfWall1();
      PRC.AreaOfWall2();
      PRC.AreaOfWall3();
      PRC.AreaOfWall4();
      PRC.AreaofAllWalls();
      PRC.AreaofWindow1();
      PRC.AreaofWindow2();
      PRC.AreaOfDoor();
      PRC.AreaWithoutOpenings();
      PRC.GallonsNeeded();
   }
}