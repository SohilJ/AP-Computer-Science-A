import java.util.Scanner;

public class PainterResourceClass1
{
   Scanner w = new Scanner(System.in);
   
   //Initialize all the variables
   private double length1;
   private double length2;
   private double length3;
   private double length4;
   private double width1;
   private double width2;
   private double width3;
   private double width4;
   private double Area1;
   private double Area2;
   private double Area3;
   private double Area4;
   private double TotalArea;
   private double lengthOfWindow1;
   private double lengthOfWindow2;
   private double widthOfWindow1;
   private double widthOfWindow2;
   private double AreaWindow1;
   private double AreaWindow2;
   private double lengthOfDoor;
   private double widthOfDoor;
   private double AreaDoor;
   private double AreaWO;
   private double paintNeeded;
   private double moneyNeed;
   
   //Make a constructor
   public PainterResourceClass1()
   {
      length1 = 0;
      length2 = 0;
      length3 = 0;
      length4 = 0;
      width1 = 0;
      width2 = 0;
      width3 = 0;
      width4 = 0;
      Area1 = 0;
      Area2 = 0;
      Area3 = 0;
      Area4 = 0;
      TotalArea = 0;
      lengthOfWindow1 = 0;
      lengthOfWindow2 = 0;
      widthOfWindow1 = 0;
      widthOfWindow2 = 0;
      AreaWindow1 = 0;
      AreaWindow2 = 0;
      lengthOfDoor = 0;
      widthOfDoor = 0;
      AreaDoor = 0;
      AreaWO = 0;
      paintNeeded = 0;
      moneyNeed = 0;
   }
   
   //Get areas of all the walls
   public void AreaOfWall1()
   {
      System.out.println("Print the length of wall 1: ");
      length1 = w.nextInt();
      System.out.println("Print the width of wall 1: ");
      width1 = w.nextInt();
      Area1 = length1*width1;
      System.out.println("The area of the first wall is: " + Area1); 
   }
   public void AreaOfWall2()
   {
      System.out.println("Print the length of wall 2: ");
      length2 = w.nextInt();
      System.out.println("Print the length of wall 2: ");
      width2 = w.nextInt();
      Area2 = length2*width2;
      System.out.println("The area of the second wall is: " + Area2); 
   }
   public void AreaOfWall3()
   {
      System.out.println("Print the length of wall 3: ");
      length3 = w.nextInt();
      System.out.println("Print the length of wall 3: ");
      width3 = w.nextInt();
      Area3 = length3*width3;
      System.out.println("The area of the third wall is: " + Area3); 
   }
   public void AreaOfWall4()
   {
      System.out.println("Print the length of wall 4: ");
      length4 = w.nextInt();
      System.out.println("Print the length of wall 4: ");
      width4 = w.nextInt();
      Area4 = length4*width4;
      System.out.println("The area of the fourth wall is: " + Area4); 
   }
   public void AreaofAllWalls()
   {
      TotalArea = Area1 + Area2 + Area3 + Area4;
      System.out.println("The area of all the walls equals: " + TotalArea);
   }
   
   //Get areas of all the windows
   public void AreaofWindow1()
   {
      System.out.println("Print the length of window 1: ");
      lengthOfWindow1 = w.nextInt();
      System.out.println("Print the width of window 1: ");
      widthOfWindow1 = w.nextInt();
      AreaWindow1 = lengthOfWindow1 * widthOfWindow1;
   }
   public void AreaofWindow2()
   {
      System.out.println("Print the length of window 2: ");
      lengthOfWindow2 = w.nextInt();
      System.out.println("Print the width of window 2: ");
      widthOfWindow2 = w.nextInt();
      AreaWindow2 = lengthOfWindow2 * widthOfWindow2;
   }
   
   //Get area of door
   public void AreaOfDoor()
   {
      System.out.println("Print the length of the door: ");
      lengthOfDoor = w.nextInt();
      System.out.println("Print the width of the door: ");
      widthOfDoor = w.nextInt();
      AreaDoor = lengthOfDoor * widthOfDoor;
   }
   
   public void AreaWithoutOpenings()
   {
      AreaWO= TotalArea - AreaWindow1 - AreaWindow2 - AreaDoor;
      System.out.println("The total area without openings is: " + AreaWO);
   }
   
   public void GallonsNeeded()
   {
      paintNeeded = AreaWO/400;
      System.out.println("You will need " + paintNeeded + " gallons of paint");
      
      moneyNeed = paintNeeded * 30;
      System.out.println("The price of " + paintNeeded + " gallons is " + moneyNeed + " dollars.");
   }
   
   
}