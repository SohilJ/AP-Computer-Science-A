import javax.swing.*;
import java.awt.*;
import java.util.Scanner;

public class Wheel
{

   public static void main(String[] args)
   {
   
      wheelClass wheel = new wheelClass();
      wheel.getDiameter();
      wheel.calcCircumference();
      wheel.calcRotations();
      wheel.calcRevolutions();
   
   }
}
