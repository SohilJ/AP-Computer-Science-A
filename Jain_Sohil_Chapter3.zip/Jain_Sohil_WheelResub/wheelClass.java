import javax.swing.*;
import java.awt.*;
import java.util.Scanner;

public class wheelClass
{
Scanner keyboard = new Scanner(System.in);
private double diameter;
private double circumference;
private double mile;
private double tripMiles;
private double tripRev;

public void getDiameter()
{
//Asks user to input diameter
System.out.println(" Input Diameter ");
diameter = keyboard.nextInt();
System.out.println(diameter + " Diameter = inches" );
}
public void calcCircumference()
{
//Equation to find Circumference
circumference = diameter * Math.PI;
System.out.println(" The distance of one revolution is " + circumference);
}
public void calcRotations()
{
//Equation to find rotations in a mile
mile = 63360 / circumference;
System.out.println("The rotations in one mile is " + mile);
}
public void calcRevolutions()
{
//Asks user to input number of miles
System.out.println(" Input number of miles ");
tripMiles = keyboard.nextInt();
tripRev = mile * tripMiles;
System.out.println(" The number of revolutions in the trip is " + tripRev);
}

}