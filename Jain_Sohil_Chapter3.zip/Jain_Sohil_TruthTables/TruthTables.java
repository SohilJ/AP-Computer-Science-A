public class TruthTables {
   public static void main(String[] args)
   {
      boolean abe, barney; //the two variables that will be used in the tables
      
      //AND Gate
      System.out.println("AND Gate");
      System.out.println("a       b       a && b");
      
      abe = true; barney = abe;
      System.out.println(abe+"    "+barney+"    "+(abe&&barney));
      
      barney = false;
      System.out.println(abe+"    "+barney+"   "+(abe&&barney));
      
      abe = barney; barney = true;
      System.out.println(abe+"   "+barney+"    "+(abe&&barney));
      
      barney = abe;
      System.out.println(abe+"   "+barney+"   "+(abe&&barney));
      
      System.out.println(""); //a blank line to seperate the two gates
      
      //OR Gate
      System.out.println("OR Gate");
      System.out.println("a       b       a || b");
      
      abe = true; barney = abe;
      System.out.println(abe+"    "+barney+"    "+(abe||barney));
      
      barney = false;
      System.out.println(abe+"    "+barney+"   "+(abe||barney));
      
      abe = barney; barney = true;
      System.out.println(abe+"   "+barney+"    "+(abe||barney));
      
      barney = abe;
      System.out.println(abe+"   "+barney+"   "+(abe||barney));
      
      System.out.println(""); //a blank line to seperate the two gates
      
      //XOR Gate
      System.out.println("XOR Gate");
      System.out.println("a       b       a ^ b"); //^ is the operator for exclusive or
      
      abe = true; barney = abe;
      System.out.println(abe+"    "+barney+"    "+(abe^barney));
      
      barney = false;
      System.out.println(abe+"    "+barney+"   "+(abe^barney));
      
      abe = barney; barney = true;
      System.out.println(abe+"   "+barney+"    "+(abe^barney));
      
      barney = abe;
      System.out.println(abe+"   "+barney+"   "+(abe^barney));
      
      System.out.println(""); //a blank line to seperate the two gates
         
      //NOT Gate
      System.out.println("NOT Gate");
      System.out.println("a       b       ~a       ~b");
      
      abe = true; barney = abe;
      System.out.println(abe+"    "+barney+"    "+(!abe)+"    "+(!barney));
      
      abe = true; barney = false;
      System.out.println(abe+"    "+barney+"   "+(!abe)+"    "+(!barney));
      
      abe = barney; barney = true;
      System.out.println(abe+"   "+barney+"    "+(!abe)+"     "+(!barney));
      
      barney = abe;
      System.out.println(abe+"   "+barney+"   "+(!abe)+"     "+(!barney));
      
   }
}

